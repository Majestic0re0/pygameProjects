quit = False
while quit != True:
    print()
    print()
    print("This program converts Fahrenheit to Celsius")
    print("write to degree of the fahrenheit temperature below")
    temperatureInFahrenheit = input("temperatureInFahrenheit: ")
    temperatureInFahrenheit = float(temperatureInFahrenheit)
    print()
    conversionToCelsius = (temperatureInFahrenheit - 32) * (5 / 9)
    print(conversionToCelsius)
    print("This is your answer in Celsius")
    print()
    quitValue = input("Do you want to quit? press Y to quit: ")
    if quitValue.upper() == "Y":
        quit = True
        print("You have quit")
