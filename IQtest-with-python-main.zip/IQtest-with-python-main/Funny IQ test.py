print("This is a quiz on random stuff")
print("Try your best and answer.")
print("There are 8 questions")
print("BEGIN!")

print()
print()
print()

total = 0

questionOne = input("Are you smart? this is a Yes or No answer: ")
if questionOne.lower() == "yes":
    print("correct, +20 iq")
    total += 1
else:
    print("Don't worry, not everyone is.")
    print("You failed this question.")
    print("The answer has to be yes, because I believe that you are smart")

print()
print()
print()

questionTwo = input("Who wrote \"do you like green eggs and ham, sam i am\"? ")
if questionTwo.lower() == "dr. seuss":
    print("Correct")
    total += 1
elif questionTwo.lower() == "seuss":
    print("Correct")
    total += 1
elif questionTwo.lower() == "dr seuss":
    print("Correct")
    total += 1
else:
    print("Wrong, -2000 iq")
    print("It was Dr Seuss, come on now!")


print()
print()
print()

print("A.) I love all my students")
print("B.) All my students are bums, i hate them all")
print("C.) The smart kid is my favourite")
print("D.) Of Course you are the best student i have seen all my life")
print()
print("choose from the options above, (A,B,C,D)")
questionThree = input("Who is your most favorite student(Choose the maker of this quiz! >:C )")
if questionThree.upper() == "D":
    print("Wow, what a surprise, i didn't know you would pick me")
    print("You got it correct, + INFINITY IQ")
    total += 1
else:
    print("Wrong, i literally told you the answer, it is D")

print()
print()
print()

questionFour = input("Mary's Father has 5 daughters, nana, nene, nini, nono..but what is the name of the 5th daughter?")
if questionFour.upper() == "MARY":
    print("How wrong of you to assume Mary was a female, you still got it right though.")
    total += 1
else:
    print("You got it wrong, at lease i hope you didn't choose Nunu")
    print("The answer is Mary")

print()
print()
print()

questionFive = input("What comes once in a minute, twice in a moment, but never in a thousand years?")
if questionFive.upper() == "M":
    print("You are quite smart")
    total += 1
else:
    print("You disgrace me, the answer is M")

print()
print()
print()

print("You live in a bungalow made of redwood, what color is the stairs?")
print("A.) No color")
print("B.) Red")
print("C.) Blue")
print("D.) Yellow")

questionSix = input("What is your answer?: ")
if questionSix.upper() == "A":
    print("Damn son, you are pretty percipient. As you can tell, i am a bit of a sesquipedalian.")
    total += 1
else:
    print("That's tuff, the answer is A, you live in a bungalow, there are no stairs....Duh")

print()
print()
print()

print("I am not alive,but I grow;I don't have lungs,but I need air; I don't have a mouth,but water kills me.What am I?")
questionSeven = input("What is your answer?: ")
if questionSeven.upper() == "FIRE":
    print("You are too wise great one!")
    total += 1
else:
    print("The answer is Fire, but on the \"bright side though\", now you learnt something new,don't put water on fire")


print()
print()
print()

questionEight = input("How many planets are there in our solar system(The most recent data): ")
if questionEight.lower() == "8":
    print("Correct")
    total += 1
else:
    print("If you thought 9, close but pluto is no longer a planet.")
    print()
    print()

if total <= 8 >= 6:
    print("Good job")
elif total <= 5 >= 3:
    print("You tried")
else:
    print("Well um....at least you completed the quiz. So...umm, we gotta work on that iq")
    print()
print("You have completed the Quiz, YAY!")

print("Your score is", total, "out of 8")
